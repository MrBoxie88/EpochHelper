---
name: Bug Report
about: Report a problem with EpochHelper
title: "[BUG] "
labels: bug
assignees: ''
---

**Describe the bug**
A clear description of what went wrong.

**Steps to reproduce**
1. ...
2. ...

**Expected behavior**
What should have happened.

**Lua error (if any)**
Paste any error from the Lua error popup.

**Your setup**
- WoW version: 3.3.5a
- Server: Project Epoch
- Other addons running: (list any)
