---
name: Quest Submission
about: Submit waypoint data for a quest not in the database
title: "[QUEST] Quest Name Here"
labels: quest-submission
assignees: ''
---

## Quest Info

**Quest Title:** (exact name as it appears in your quest log)
**Quest ID:** (type `/script print(GetQuestID())` while the quest is selected in your log)
**Zone:** (which zone the objective is in)
**Server:** Project Epoch

## Waypoints

Paste your exported data below. In-game type `/eh export` then copy the output.

```lua
-- Paste your /eh export output here
```

## Steps (if multiple objectives)

If the quest has multiple steps, list them in order:

1. Step 1 hint text
2. Step 2 hint text

## Notes

Any extra context about the quest (NPC names, spawn locations, etc.)
